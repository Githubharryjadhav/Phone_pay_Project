import { SendTransaction } from './send-transaction';

describe('SendTransaction', () => {
  it('should create an instance', () => {
    expect(new SendTransaction()).toBeTruthy();
  });
});
