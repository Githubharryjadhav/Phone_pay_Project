export class SendTransaction {

    mobile:number=0;
    amount: number=0;
    bank: string="";
    pin: string="";

}
